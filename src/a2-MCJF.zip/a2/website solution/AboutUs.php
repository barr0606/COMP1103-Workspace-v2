<?php
include 'inc/header.php';
?>

<head>
    <meta charset="UTF-8">
    <meta author="Fletcher Barry" description="About Us Page for Pet Sanctuary">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us</title>
    <link rel="stylesheet" href="styles/style.css">
</head>

<body>
    <main>
        <h2>About Us</h2>
        <fieldset>
            <legend>Our Mission</legend>
            <table class="no-hover">
                <tr class="no-hover">
                    <td class="no-hover">
                        <img class="about-us-img" src="imgs/aboutus-1.jpeg" alt="A picture of 2 dogs and 3 cats lined up in a rown in a meddow.">
                    </td>
                    <td class="no-hover">
                        <p>
                            At Pet Sanctuary, our mission is to provide a safe, loving home to animals in need. <br> We accomplish this by connecting with out local community, and providing help to those who's pets need care. <br> By doing this, we hope to build a reputation for our name such that when a person would want to adopt a pet, <br> they would think of us first.
                        </p>
                    </td>
                </tr>
            </table>
        </fieldset>
    </main>
</body>


<?php
include 'inc/footer.php';
?>